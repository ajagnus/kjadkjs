# TM1 - Programming Essentials in Python 

Class materials for TM1.